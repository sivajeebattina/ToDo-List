//
//  Task.h
//  To-DoList
//
//  Created by pcs20 on 9/30/14.
//  Copyright (c) 2014 Paradigmcreatives. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Task : NSObject

@property(nonatomic,strong)NSString *taskName;
@property(nonatomic,strong)NSString *date;



@end
